rm(list = ls())  # remove the existing environment

## You should set the working directory to the folder of hw3_starter by
## uncommenting the following and replacing YourDirectory by what you have
## in your local computer / labtop

# setwd("YourDirectory/Q2_starter")

## Load utils.R and discriminant_analysis.R

source("utils.R")
source("discriminant_analysis.R")


## Load the training and test data
train <- Load_data("./data/digits_train.txt")
test <- Load_data("./data/digits_test.txt")

x_train <- train$x
y_train <- train$y

x_test <- test$x
y_test <- test$y

### Visualization 
## uncomment the following command to visualize the first ten digits in the training data. 
# Plot_digits(1:10, x_train)


#####################################################################
#                           Part a.                                 #
# TODO:  estimate the priors, conditional means and conditional     #
#        covariance matrices under LDA,                             #
#        predict the labels of test data by using the fitted LDA    #
#        compute its misclassification error rate                   #
#####################################################################

priors <- NA
means <- NA
covs <- NA

#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################



#####################################################################
#                           Part b.                                 #
# TODO:  estimate the priors, conditional means and conditional     #
#        covariance matrices under QDA,                             #
#        predict the labels of test data by using the fitted LDA    #
#        compute its misclassification error rate                   #
#####################################################################

priors <- NA
means <- NA
covs <- NA


#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################






#####################################################################
#                           Part c.                                 #
# TODO:  estimate the priors, conditional means and conditional     #
#        covariance matrices under the Gaussian Naive Bayes (NB)    #
#        predict the labels of test data by using the fitted NB     #
#        compute its misclassification error rate                   #
#####################################################################

priors <- NA
means <- NA
covs <- NA


#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################






#####################################################################
#                           Part d.                                 #
# TODO:  fit LDA and QDA by using the R package                     #
#        report their test errors and compare running time          #
#####################################################################

library(MASS)


#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################



