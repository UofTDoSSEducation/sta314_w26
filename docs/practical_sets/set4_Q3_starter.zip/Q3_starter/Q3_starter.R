rm(list = ls())

## You should set the working directory to the folder of hw3_starter by
## uncommenting the following and replacing YourDirectory by what you have
## in your local computer / labtop

# setwd("YourDirectory/Q3_starter")

## Load utils.R and penalized_logistic_regression.R

source("utils.R")
source("penalized_logistic_regression.R")


## load data sets

train <- Load_data("./data/train.csv")
valid <- Load_data("./data/valid.csv")
test <- Load_data("./data/test.csv")

x_train <- train$x
y_train <- train$y

x_valid <- valid$x
y_valid <- valid$y

x_test <- test$x
y_test <- test$y





#####################################################################
#                           Part a.                                 #
# TODO: Find suitable choice of the hyperparameters:                #
#     - stepsize (i.e. the learning rate)                           #
#     - max_iter (the maximal number of iterations)                 #
#   The regularization parameter, lbd, should be set to 0           #
#   Draw plot of training losses and training 0-1 errors            #
#####################################################################

lbd = 0

#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################






#####################################################################
#                           Part b.                                 #
# TODO: Identify suitable stepsize and max_iter for each lambda     #
#       from the given grid. Draw the plots of training and         #
#       validation 0-1 errors versus different values of lambda     #
#####################################################################


stepsize <- 0  # this should be replaced by your answer in Part a
max_iter <- 0  # this should be replaced by your answer in Part a

lbd_grid <- c(0, 0.01, 0.05, 0.1, 0.5, 1)



#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################







#####################################################################
#                           Part c.                                 #
# TODO: using the chosen stepsize,  max_iter and lbd you found, fit # 
#  the penalized logistic regression and compute its test 0-1 error #
#####################################################################


stepsize <- 0  # this should be replaced by your answer in Part a
max_iter <- 0  # this should be replaced by your answer in Part a
lbd <- 0       # this should be replaced by your answer in Part b


#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################




#####################################################################
#                           Part d.                                 #
# TODO: Use your implementation of LDA and Naive Bayes in Problem 2 #
#   to classify the test data points and report test 0-1 errors     #
#####################################################################

source("discriminant_analysis.R")

#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################



#####################################################################
#                           Part e.                                 #
# TODO: based on the test data, draw the ROC curve and compute AUC  #
#  of your implemented penalized logistic regression, LDA and NB    #
#####################################################################



#####################################################################
#                       END OF YOUR CODE                            #
#####################################################################



